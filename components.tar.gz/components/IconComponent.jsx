import 'material-icons/iconfont/material-icons.css'
// Importa los estilos de Material Icons

function IconComponent ({ icon, css }) {
  const className = 'material-icons '
  return (
    <i className={'icon ' + className + css}>{icon}</i>
  )
}

export default IconComponent
