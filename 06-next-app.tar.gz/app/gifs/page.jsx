import ListOfGifs from "@/components/ListOfGifs";

export default function AboutPage() {


  return (
    <main>
      <h1>Gifs</h1>
      <ListOfGifs />
    </main>
  );
}
