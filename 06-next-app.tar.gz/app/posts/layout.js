export default function PostsLayout ({ children }) {
    return (
        <main>
            {children}
        </main>
    )
}