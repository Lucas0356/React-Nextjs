export default function Home () {
  return (
    <main>
      <h1>App con Next.js</h1>
    </main>
  )
}
