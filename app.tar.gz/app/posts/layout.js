import { SearchBar } from '@/components/SearchBar'

export default function PostsLayout ({ children }) {
    return (
        <main>
            {/* <SearchBar /> */}
            {children}
        </main>
    )
}