// Mock de datos
import posts from '../mocks/posts.json'
// Estilos
import './ListOfPosts.css'

export default function ListOfPosts () {
  const hasPosts = posts?.length > 0

  return (
    <>
      {hasPosts
        ? (
            posts.slice(0, 5).map((post) => (
              <article className='post' key={post.id}>
                <h3>{post.title}</h3>
                <p>{post.body}</p>
              </article>
            ))
          )
        : (
          <article>
            <p>No se han encontrados posts</p>
            <img src='https://http.cat/images/404.jpg' alt='error 404 not found image cat' />
          </article>
          )}
    </>
  )
}
