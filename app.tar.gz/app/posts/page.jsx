import ListOfPosts from './ListOfPosts'

export default function postsPage () {
  return (
    <main>
      <h1>Posts</h1>
      <section style={{ display: 'flex' }}>
        <ListOfPosts />
      </section>
    </main>
  )
}
