import ListOfPosts from '../../components/ListOfPosts'

export default function postsPage () {
  return (
      <ListOfPosts />
  )
}
