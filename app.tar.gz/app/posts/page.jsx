import ListOfPosts from '../../components/ListOfPosts'

export default function postsPage () {
  return (
    <main>
      <ListOfPosts />
    </main>
  )
}
