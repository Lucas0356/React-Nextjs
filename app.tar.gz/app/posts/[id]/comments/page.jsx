import ListOfComments from "@/components/ListOfComments";

export default function comments () {
    return (
        <ListOfComments />
    )
}