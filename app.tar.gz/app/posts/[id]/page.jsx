export default function empty () {
    return null
}