export default function AboutPage () {
  return (
    <main>
      <h1>About page</h1>
    </main>
  )
}
